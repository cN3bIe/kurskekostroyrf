<? 
if(isset($_REQUEST['action'])  && !empty($_REQUEST['action']))
{
	$action = $_REQUEST['action'];
	$AJAX = new OurAjax();
	if(method_exists($AJAX,$action))
	{
		$AJAX->$action();
	}
	else
	{
		// echo 'Method '.$action.' is not exists!';
		exit();
	}

}


class OurAjax
{

	function __construct()
	{
		
	}
	
	function knowMore()
	{
		if(isset($_REQUEST['phone']) && isset($_REQUEST['fio']))
		{
			$path = 'http://'. $_SERVER["SERVER_NAME"].str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']); 
			$admin_from_email = 'web_ea@rehau.com';
			$to_emails = 'nechekhov@yandex.ru'; // куда придет запрос, можно указать сразу несколько адресов, через запятую 
			$header .="FROM: {$admin_from_email}\n";
			$header .= "Content-Type: text/html; charset=utf-8\n"; // обратить внимание
			$header .= "X-From: {$admin_from_email}\n";
			$header .= "Return-Path:{$admin_from_email}\n";
			
			$body = '
				<!DOCTYPE html>
				<html lang="ru">
				<head>
				    <title>Home</title>
				    <meta name = "format-detection" content = "telephone=no" />
				    <meta charset="utf-8">
				    <link rel="icon" href="'.$path.'images/favicon.ico" type="image/x-icon">
				    <link rel="shortcut icon" href="'.$path.'images/favicon.ico" type="image/x-icon" />
				    <link rel="stylesheet" type="text/css" media="all" href="'.$path.'css/style.css">
				</head>
				<body id="body_main">
				

				<div class="container" style="width:800px;margin:0 auto;min-height:400px;padding-top:50px">
				<h2 class="title1 reg pb30">На странице '. $path.'<BR>заполнена форма "узнать больше"</h2>
				<ul class="left_to_right_list">
	              <li class="left_to_right_list_item">
	                ФИО : '.$_REQUEST['fio'].'. 
	              </li>
	              <li class="left_to_right_list_item">
	                Телефон : '.$_REQUEST['phone'].'. 
	              </li>
				</ul>	
							
				</div>
				</body>
				</html>
			';
			
			mail($to_emails,'Okna, Zapros #'.time(),$body,$header);
        						
		}	
	}

	function zamer()
	{
		if(isset($_REQUEST['phone']) && isset($_REQUEST['fio']))
		{
			$path = 'http://'. $_SERVER["SERVER_NAME"].str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']); 
			$admin_from_email = 'web_ea@rehau.com';
			$to_emails = 'nechekhov@yandex.ru'; // куда придет запрос, можно указать сразу несколько адресов, через запятую 
			$header .="FROM: {$admin_from_email}\n";
			$header .= "Content-Type: text/html; charset=utf-8\n"; // обратить внимание
			$header .= "X-From: {$admin_from_email}\n";
			$header .= "Return-Path:{$admin_from_email}\n";
			
			$body = '
				<!DOCTYPE html>
				<html lang="ru">
				<head>
				    <title>Home</title>
				    <meta name = "format-detection" content = "telephone=no" />
				    <meta charset="utf-8">
				    <link rel="icon" href="'.$path.'images/favicon.ico" type="image/x-icon">
				    <link rel="shortcut icon" href="'.$path.'images/favicon.ico" type="image/x-icon" />
				    <link rel="stylesheet" type="text/css" media="all" href="'.$path.'css/style.css">
				</head>
				<body id="body_main">
				

				<div class="container" style="width:800px;margin:0 auto;min-height:400px;padding-top:50px">
			<h2 class="title1 reg pb30">На странице '. $path.'<BR>заполнена форма "Заявка на замер"</h2>
				<ul class="left_to_right_list">
	              <li class="left_to_right_list_item">
	                ФИО : '.$_REQUEST['fio'].'. 
	              </li>
	              <li class="left_to_right_list_item">
	                Телефон : '.$_REQUEST['phone'].'. 
	              </li>
				</ul>	
							
				</div>
				</body>
				</html>
			';
			
			mail($to_emails,'Okna - Zapros Zamer #'.time(),$body,$header);
        						
		}	
	}	
	
	function callMe()
	{
		if(isset($_REQUEST['phone']) && isset($_REQUEST['fio']))
		{
			$path = 'http://'. $_SERVER["SERVER_NAME"].str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']); 
			$admin_from_email = 'web_ea@rehau.com';
			$to_emails = 'nechekhov@yandex.ru'; // куда придет запрос, можно указать сразу несколько адресов, через запятую 
			$header .="FROM: {$admin_from_email}\n";
			$header .= "Content-Type: text/html; charset=utf-8\n"; // обратить внимание
			$header .= "X-From: {$admin_from_email}\n";
			$header .= "Return-Path:{$admin_from_email}\n";	
			
			$body = '
				<!DOCTYPE html>
				<html lang="ru">
				<head>
				    <title>Home</title>
				    <meta name = "format-detection" content = "telephone=no" />
				    <meta charset="utf-8">
				    <link rel="icon" href="'.$path.'images/favicon.ico" type="image/x-icon">
				    <link rel="shortcut icon" href="'.$path.'images/favicon.ico" type="image/x-icon" />
				    <link rel="stylesheet" type="text/css" media="all" href="'.$path.'css/style.css">
				</head>
				<body id="body_main">
				

				<div class="container" style="width:800px;margin:0 auto;min-height:400px;padding-top:50px">
			<h2 class="title1 reg pb30">На странице '. $path.'<BR>заполнена форма "Перезвоните мне!"</h2>
				<ul class="left_to_right_list">
	              <li class="left_to_right_list_item">
	                ФИО : '.$_REQUEST['fio'].'. 
	              </li>
	              <li class="left_to_right_list_item">
	                Телефон : '.$_REQUEST['phone'].'. 
	              </li>
				</ul>	
							
				</div>
				</body>
				</html>
			';
			
			mail($to_emails,'Okna - Perezvonite, zayavka ID:'.time(),$body,$header);
        						
		}	
	}
} 
?>


