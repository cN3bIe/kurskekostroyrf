// ==================counter
$(document).ready(function(){


  // (function(){
  //   function getSpacePosition(str){

  //     var temp = "",
  //       i = 0,
  //       firstPart,
  //       secondPart;

  //     while(str.charAt(i) != "."){
  //       temp += str.charAt(i);
  //       i++;
  //     }
  //     firstPart = temp.slice(0, temp.length - 3);
  //     secondPart = temp.slice(temp.length - 3);
  //     return firstPart + " " + secondPart + ".";
  //   }

  //   $('.counter').each(function(){

  //       var $this = $(this),
  //         input = $this.children('input'),
  //         output = $this.closest('tr').find('.total_cost');
  //         output.data('price', parseFloat(output.text().split(" ").join(""),10));

  //         $this.on('click','button', function(){


  //           var currentVal = +input.val(),
  //           cO = parseFloat(output.text().split(" ").join(""),10);
  //           direction = $(this).hasClass('basket_minus') ? 'minus' : 'plus';

  //           if( +input.val()  == 0 && direction == "minus") return;
            
  //           if(direction == "plus"){
  //             input.val(++currentVal); 
  //             $(this).parents("tr").addClass("active");
  //             output.text(getSpacePosition(currentVal * output.data('price') + "руб."));
  //           }
  //           else{
  //             input.val(--currentVal); 
  //             if(currentVal == 0) $(this).parents("tr").removeClass("active");
  //             output.text(getSpacePosition(cO - output.data('price') + "руб.")); 
  //           }
  //         });
  //       }); 


     
  //     }());
  //     //кнопка принт
        $(function() {
          $(".modal1").find('.print').on('click', function() {
            $.print(".modal1");
          });
        });
     

  //     // ----------------formstyler---------- 
  //     $(".styler").styler();
  //     // ----------------animate wow---------- 
          new WOW().init();
  
      // arcticmodal
      $(".open_btn").on('click',function(){
          var modal = $(this).data("modal");
          $(modal).arcticmodal();
      });

        // anchor
        // $('.table_products').on('click',function () { 
        //    elementClick = $(this).attr("href");
        //    destination = $(elementClick).offset().top;
        //      $('html,body').animate( { scrollTop: destination }, 1100 );
        //    return false;
        //  });

        // fancybox
        // $(".fancybox").fancybox({
        //   openEffect  : 'none',
        //   closeEffect : 'none'
        // });

      // ---------------удаление  объекта
          $('.delete_btn').on('click',function(){
            $(this).parents('.sustem_box').remove()
          });

        // // tooltip

        $('.toggle_box').on('click', '.close', function(){
          $(this).closest('.toggle_box').removeClass('opened');
        });

		 $('.toggle_box2').on('click', '.close', function(){
          $(this).closest('.toggle_box2').removeClass('opened');
        });
		
		$('.toggle_box3').on('click', '.close', function(){
          $(this).closest('.toggle_box3').removeClass('opened');
        });
		
        $('.toggle_link').on('click', function(e){
          e.preventDefault();

          var message = $(this).next('.toggle_box');
          $(".toggle_box").removeClass('opened');
          message.toggleClass('opened');
    
          // var firstClick = true;
                $(document).on('click.myEvent', function(e) {
                    if (!$(e.target).hasClass('toggle_link') && $(e.target).closest('.toggle_box,.delete_btn').length == 0) {
                        message.removeClass('opened');
                        $(document).off('click.myEvent');
                    }
                    // firstClick = false;
                });          
          
        });

      $(".toggle_link_extra, #toggle_box2 .close").on("click", function(event){
        $("#toggle_box3,#toggle_box4").hide().removeClass("active");
        $("#toggle_box2").toggle().addClass("active");
        event.preventDefault();

      })
      $(".toggle_link_extra2, #toggle_box3 .close").on("click", function(event){
        $("#toggle_box2,#toggle_box4").hide().removeClass("active");
        $("#toggle_box3").toggle().addClass("active");
        event.preventDefault();
      })
      $(".toggle_link_extra3, #toggle_box4 .close").on("click", function(event){
        $("#toggle_box2,#toggle_box3").hide().removeClass("active");
        $("#toggle_box4").toggle().addClass("active");
        event.preventDefault();
      })

      $(document).on("click touchstart", function(event) {
        if ($(event.target).closest("#toggle_box2, #toggle_box3, .toggle_link_extra, .toggle_link_extra2, .toggle_link_extra3").length) return;
        $("#toggle_box2.active, #toggle_box3.active, #toggle_box4.active").hide();
        event.stopPropagation();
      })

        // table-down in popup 
     $(document).ready(function(){
         $('.review_btn').on('click',function(){
            $('.write_forms td').slideToggle("slow");
            // $(this).addClass("active");
         });
      });
  

// =================owl-carousel===================
        if($('.owl-carousel').length){
          $('.owl-carousel').each(function(){
              var itemA = $(this).attr('data-itemA'),
                  itemB = $(this).attr('data-itemB'),
                  itemC = $(this).attr('data-itemC'),
                  itemD = $(this).attr('data-itemD'), 
                  itemE = $(this).attr('data-itemE');
              $(this).owlCarousel({
                  // loop: true ,
                   margin: 10 , 
                   nav: true ,
                   smartSpeed:1000,
                   responsive: {
                      0 : {
                           items: itemE 
                      },
                      960 : {
                           items: itemD 
                      }, 
                      1358 : {
                           items: itemC 
                      },
                      1600 : {
                           items: itemB 
                      },
                      1900 : {
                           items: itemA 
                      }
                  }
              });   
          });
        };
        // mask (add file)
          // $('.custom-file-input').on('change', function() {
          //   realVal = $(this).val();
          //   lastIndex = realVal.lastIndexOf('\\') + 1;
          //   if(lastIndex !== -1) {
          //      realVal = realVal.substr(lastIndex);
          //      $(this).prev('.mask').find('.fileInputText').val(realVal);
          //   }
          // });
          // $('.custom-file-input').on('mouseenter mouseleave', function() {
          //    $(this).prev('.mask').find('.send-file').toggleClass('hovered');
          // });
        //--------------masked input--------
          $(function($){
            if( $(".date").length || $(".phone").length){
              // $(".date").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
             // $(".phone").mask("+7(999) 999-99-99");
            }
          });

          if($("#countdown-3").length){
            $('#countdown-3').timeTo({
              // timeTo: new Date('8  Jul 2015'),
			 //  timeTo: { seconds: 100 },
			  seconds: 86400,
              displayDays: 2,
              theme: "black",
              displayCaptions: true,
              fontSize: 48,
              captionSize: 14
            });  
          };
          
        
});
