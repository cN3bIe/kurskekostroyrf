$(function(){
	$('a[nam]').click(function(event){
		event.preventDefault();
		var num = $(this).attr('num');
		var nam = $(this).attr('nam');
		console.log(nam+'=='+num);
		var block = ''+
			'<div class="sustem_box first clearfix" numa="'+num+'">'+
              '<div class="f_left sustem_box_link">'+
                '<a class="order_link green" href="#">REHAU '+nam+'</a>'+
              '</div>'+
              '<div class="f_right">'+
                '<span class="delete_btn" onclick="$(this).parents(\'.sustem_box\').remove()"></span>'+
              '</div>'+
            '</div>';
		if(!$('div[numa="'+num+'"]').length || $('div[numa="'+num+'"]').length==0)
		{
			$('#compareH1').append(block);
		}
	});
	
	$('#compareAll').click(function(){
		var nums = 0;
		$('#compareTable tr td').hide();
		$.each($('div[numa]'),function(){
			nums = $(this).attr('numa');
			$.each($('#compareTable tr'),function(){
				var tds = $(this).find('td');
				
				for(a = 0; a<= tds.length; a++)
				{
					// alert(a);
					console.log(a);
					if(a == nums || a==0)
					{
						// alert(a);					
						$(tds[a]).show();
					}
				}
			});
		});
	});
	
	$('#call1').on('click',function(e){
		e.preventDefault();
		var errors = 0;
		var fio = $('#fio_call1').val();
		var phone = $('#phone_call1').val();
				
		if(fio == '')
		{
			$('#fio_call1').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#fio_call1').css({'border-color':'#B9B9B9'});
		}
		if(phone == '')
		{
			$('#phone_call1').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#phone_call1').css({'border-color':'#B9B9B9'});
		}		

		var A = {
			action : 'callMe',
			'fio' : fio,
			'phone' : phone
		};
		
		// alert(errors);
		
		if(errors == 0)
		{
			$.post('ajax.php', A , function(data){
				$('#fio_call1').val('');
				$('#phone_call1').val('');
				$('div.toggle_box').removeClass('opened');
			});
		}		
					
	});		
	
	$('#call2').on('click',function(e){
		e.preventDefault();
		var errors = 0;
		var fio = $('#fio_call2').val();
		var phone = $('#phone_call2').val();
				
		if(fio == '')
		{
			$('#fio_call2').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#fio_call2').css({'border-color':'#B9B9B9'});
		}
		if(phone == '')
		{
			$('#phone_call2').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#phone_call2').css({'border-color':'#B9B9B9'});
		}		

		var A = {
			action : 'callMe',
			'fio' : fio,
			'phone' : phone
		};
		
			// alert(errors);
			
		if(errors == 0)
		{
			$.post('ajax.php', A , function(data){
				$('#fio_call2').val('');
				$('#phone_call2').val('');
				$('div.toggle_box').removeClass('opened');
			});
		}		
					
	});		

	$('#call3').on('click',function(e){
		e.preventDefault();
		var errors = 0;
		var fio = $('#fio_call3').val();
		var phone = $('#phone_call3').val();
				
		if(fio == '')
		{
			$('#fio_call3').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#fio_call3').css({'border-color':'#B9B9B9'});
		}
		if(phone == '')
		{
			$('#phone_call3').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#phone_call3').css({'border-color':'#B9B9B9'});
		}		

		var A = {
			action : 'callMe',
			'fio' : fio,
			'phone' : phone
		};
		
			// alert("#3 " + errors);
			
		if(errors == 0)
		{
			$.post('ajax.php', A , function(data){
				$('#fio_call3').val('');
				$('#phone_call3').val('');
				$('div.toggle_box').removeClass('opened');
			});
		}		
					
	});		

	$('#know_more').on('click',function(e){
		e.preventDefault();
		var errors = 0;
		var fio = $('#fio_know').val();
		var phone = $('#phone_know').val();
				
		if(fio == '')
		{
			$('#fio_know').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#fio_know').css({'border-color':'#B9B9B9'});
		}
		if(phone == '')
		{
			$('#phone_know').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#phone_know').css({'border-color':'#B9B9B9'});
		}		

		var A = {
			action : 'knowMore',
			'fio' : fio,
			'phone' : phone
		};
		
		if(errors == 0)
		{
			$.post('ajax.php', A , function(data){
				$('#fio_know').val('');
				$('#phone_know').val('');
				$('div.toggle_box4').removeClass('opened');
			});
		}		
					
	});	
	
	$('#zamer').on('click',function(e){
		e.preventDefault();
		var errors = 0;
		var fio = $('#fio_zamer').val();
		var phone = $('#phone_zamer').val();
				
		if(fio == '')
		{
			$('#fio_zamer').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#fio_zamer').css({'border-color':'#B9B9B9'});
		}
		if(phone == '')
		{
			$('#phone_zamer').css({'border-color':'#b0356a'});
			errors = 1;
		}
		else
		{
			$('#phone_zamer').css({'border-color':'#B9B9B9'});
		}		

		var A = {
			action : 'zamer',
			'fio' : fio,
			'phone' : phone
		};
		
			// alert(errors);
			
			
		if(errors == 0)
		{
			$.post('ajax.php', A , function(data){
				$('#fio_zamer').val('');
				$('#phone_zamer').val('');
				$('div.toggle_box').removeClass('opened');
			});
		}		
					
	});		
	
});


$(document).on("click touchstart", function(event) {
    if($(event.target).closest("#toggle_box2, #toggle_box3, .toggle_link_extra, .toggle_link_extra2").length) return;
        $("#toggle_box2.active, #toggle_box3.active").hide();
        event.stopPropagation();
});